public class GooglePay {
    public void makePayment(double amount) {
        System.out.println("Payment of Rs" + amount + " is made using Google Pay.");
    }
}
