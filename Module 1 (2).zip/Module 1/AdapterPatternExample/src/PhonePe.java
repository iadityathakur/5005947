public class PhonePe {
    public void sendPayment(double amount) {
        System.out.println("Payment of Rs" + amount + " is made using PhonePe.");
    }
}
