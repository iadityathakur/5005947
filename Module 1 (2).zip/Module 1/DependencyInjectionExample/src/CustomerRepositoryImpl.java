public class CustomerRepositoryImpl implements CustomerRepository {
    @Override
    public Customer findCustomerById(String id) {
        // In a real application, this would query the database
        return new Customer(id, "Ritesh Patnaik", "riteshpatnaik@gmail.com");
    }
}
