public class TestStrategyPattern {
    public static void main(String[] args) {
        PaymentContext context = new PaymentContext();

        // Pay using Credit Card
        PaymentStrategy creditCardPayment = new CreditCardPayment("1234-5678-9999-1234", "Ritesh Patnaik", "123", "08/30");
        context.setPaymentStrategy(creditCardPayment);
        context.executePayment(250.00);

        System.out.println("");

        // Pay using PayPal
        PaymentStrategy payPalPayment = new PayPalPayment("riteshpatnaik@gmail.com");
        context.setPaymentStrategy(payPalPayment);
        context.executePayment(150.00);
    }
}
