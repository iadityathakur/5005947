public class TestMVCPattern {
    public static void main(String[] args) {
        // Create a student
        Student student = new Student("35", "Ritesh Patnaik", "O");

        // Create a view to display student details
        StudentView view = new StudentView();

        // Create a controller
        StudentController controller = new StudentController(student, view);

        // Display initial student details
        controller.updateView();

        // Update student details
        controller.setStudentName("Ritesh Patnaik");
        controller.setStudentGrade("O+");

        // Display updated student details
        controller.updateView();
    }
}
